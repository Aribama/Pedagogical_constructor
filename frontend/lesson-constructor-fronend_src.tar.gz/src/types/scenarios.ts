/**
 * Профиль занятия (паспорт урока).
 * Это НЕ дидактические приёмы, а мета-информация сценария.
 */
export type LessonProfile = {
  emotionality: string;
  day_time: "begin" | "middle" | "end";
  group_size: number;
  duration_min: number;
  teacher_notes: string;
};

/**
 * Элемент сценария (один дидактический приём в последовательности)
 */
export type ScenarioItem = {
  id: number;
  technique_card: number;              // id карточки
  technique_card_title: string;        // для списков
  position: number;

  // если задано — переопределяет card.duration_min
  custom_duration_min?: number | null;

  // вычисляемое поле от бэка
  effective_duration_min: number;
};

/**
 * Сценарий занятия
 */
export type Scenario = {
  id: number;

  // null => сценарий по умолчанию (черновик)
  name: string | null;
  note: string;

  // поля, заполняемые пользователем
  grade: number | null;
  subject: string | null;
  goal: string | null;

  // плоские поля (оставлены для совместимости)
  emotionality: string;
  day_time: "begin" | "middle" | "end";
  group_size: number;
  duration_min: number;
  teacher_notes: string;

  // вложенный профиль (основной для фронта)
  lesson_profile: LessonProfile;

  subject_content: string;
  plan_text: string;
  ai_mode: "strict" | "balanced" | "free";

  items: ScenarioItem[];

  created_at: string;
  updated_at: string;
};
