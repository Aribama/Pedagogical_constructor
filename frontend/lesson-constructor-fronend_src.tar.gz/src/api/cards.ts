import { http } from "./http";
import type { CardsListResponse, TechniqueCard } from "../types/cards";

export type Logic = "any" | "all";
export type Mode = "simple" | "advanced";

export type CardsQuery = {
  q?: string;

  // multi-select filters
  activity_type?: string[];  // active, passive, aux
  bloom_levels?: string[];   // remember, understand, apply, analyze, evaluate, create

  age_levels?: string[];     // a1,a2,a3
  work_format?: string[];    // individual,group
  skills_4k?: string[];      // critical,creative,communication,collaboration
  lesson_stage?: string[];   // start,core,final

  // numeric
  duration_max?: number;

  // panel mode + logic
  mode?: Mode;

  // simple: global "horizontal" logic for multi-select filters
  logic?: Logic;

  // advanced: per-filter logic
  logic_activity?: Logic;
  logic_bloom?: Logic;
  logic_age?: Logic;
  logic_work?: Logic;
  logic_4k?: Logic;
  logic_stage?: Logic;
};

export function toParams(q: CardsQuery): URLSearchParams {
  const p = new URLSearchParams();

  // 1) Search
  if (q.q) p.set("q", q.q);

  // 2) Mode + global logic
  const mode: Mode = q.mode ?? "simple";
  const globalLogic: Logic = q.logic ?? "any";

  p.set("mode", mode);

  // We still send "logic" for backward compatibility (if backend uses it)
  if (q.logic) p.set("logic", q.logic);

  // 3) Logic routing:
  // - simple: "horizontal" logic affects EACH multi-select filter (not between filters)
  // - advanced: per-filter logic is used
  if (mode === "simple") {
    p.set("logic_activity", globalLogic);
    p.set("logic_bloom", globalLogic);
    p.set("logic_age", globalLogic);
    p.set("logic_work", globalLogic);
    p.set("logic_4k", globalLogic);
    p.set("logic_stage", globalLogic);
  } else {
    if (q.logic_activity) p.set("logic_activity", q.logic_activity);
    if (q.logic_bloom) p.set("logic_bloom", q.logic_bloom);

    if (q.logic_age) p.set("logic_age", q.logic_age);
    if (q.logic_work) p.set("logic_work", q.logic_work);
    if (q.logic_4k) p.set("logic_4k", q.logic_4k);
    if (q.logic_stage) p.set("logic_stage", q.logic_stage);
  }

  // 4) Filters (CSV lists)
  if (q.activity_type?.length) p.set("activity_type", q.activity_type.join(","));
  if (q.bloom_levels?.length) p.set("bloom_level", q.bloom_levels.join(","));

  if (q.age_levels?.length) p.set("age_levels", q.age_levels.join(","));
  if (q.work_format?.length) p.set("work_format", q.work_format.join(","));
  if (q.skills_4k?.length) p.set("skills_4k", q.skills_4k.join(","));
  if (q.lesson_stage?.length) p.set("lesson_stage", q.lesson_stage.join(","));

  // 5) Numeric
  if (q.duration_max != null) p.set("duration_max", String(q.duration_max));

  return p;
}

/**
 * Always returns an array of cards.
 * Supports both backend formats:
 * - TechniqueCard[]
 * - { results: TechniqueCard[]; ... } (DRF pagination)
 */
export async function listCards(query: CardsQuery): Promise<TechniqueCard[]> {
  const params = toParams(query);
  const res = await http.get<TechniqueCard[] | CardsListResponse>(`/cards/?${params.toString()}`);

  const data = res.data;
  return Array.isArray(data) ? data : (data.results ?? []);
}

export async function getCard(id: number): Promise<TechniqueCard> {
  const res = await http.get<TechniqueCard>(`/cards/${id}/`);
  return res.data;
}
