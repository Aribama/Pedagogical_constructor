import { http } from "./http";

export async function generatePlan(scenario_id: number, provider: string = "stub"): Promise<{ plan_text: string }> {
  const res = await http.post<{ plan_text: string }>(`/ai/generate-plan/`, { scenario_id, provider });
  return res.data;
}
