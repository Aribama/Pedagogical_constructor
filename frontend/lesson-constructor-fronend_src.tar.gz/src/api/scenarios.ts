import { http } from "./http";
import type { Scenario } from "../types/scenarios";

/**
 * Получить сценарий по умолчанию (черновик)
 */
export async function getDefaultScenario(): Promise<Scenario> {
  const res = await http.get<Scenario>("/scenarios/default/");
  return res.data;
}

/**
 * Список "Мои сценарии"
 */
export async function listScenarios(): Promise<Scenario[]> {
  const res = await http.get<Scenario[]>("/scenarios/");
  return res.data;
}

/**
 * Получить сценарий по id
 */
export async function getScenario(id: number): Promise<Scenario> {
  const res = await http.get<Scenario>(`/scenarios/${id}/`);
  return res.data;
}

/**
 * Обновить сценарий (PATCH)
 */
export async function updateScenario(
  id: number,
  patch: Partial<Scenario>
): Promise<Scenario> {
  const res = await http.patch<Scenario>(`/scenarios/${id}/`, patch);
  return res.data;
}

/**
 * Сохранить default-сценарий с именем
 */
export async function saveDefaultAs(name: string): Promise<Scenario> {
  const res = await http.post<Scenario>("/scenarios/save-as/", { name });
  return res.data;
}

/**
 * Альтернативный save-as по id
 */
export async function saveScenarioAs(
  scenarioId: number,
  name: string
): Promise<Scenario> {
  const res = await http.post<Scenario>(
    `/scenarios/${scenarioId}/save-as/`,
    { name }
  );
  return res.data;
}

/**
 * Дублировать сценарий
 */
export async function duplicateScenario(id: number): Promise<Scenario> {
  const res = await http.post<Scenario>(`/scenarios/${id}/duplicate/`);
  return res.data;
}

/**
 * Удалить сценарий
 */
export async function deleteScenario(id: number): Promise<void> {
  await http.delete(`/scenarios/${id}/`);
}

/**
 * Сохранить дидактические приёмы сценария
 */
export async function autosaveScenarioItems(
  scenarioId: number,
  items: Array<{
    technique_card: number;
    position: number;
    custom_duration_min?: number | null;
  }>
): Promise<Scenario> {
  const res = await http.put<Scenario>(
    `/scenarios/${scenarioId}/autosave-items/`,
    { items }
  );
  return res.data;
}

/* =========================
   Alias для старого фронта
   ========================= */

export const autosaveItems = autosaveScenarioItems;
export const updateScenarioFields = updateScenario;

export async function saveAsNamed(
  scenarioId: number,
  name: string
): Promise<Scenario> {
  return saveScenarioAs(scenarioId, name);
}
