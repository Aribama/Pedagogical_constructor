export function WikiPage() {
  return (
    <div className="container" style={{ maxWidth: 1400, paddingTop: 18 }}>
      <h2 className="fw-bold mb-2">Вики</h2>
      <div className="text-muted">
        Раздел Вики в разработке.
      </div>
    </div>
  );
}
export default WikiPage;
