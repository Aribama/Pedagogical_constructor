

export function UsersPage() {
  return (
    <div className="container">
      <h3>Пользователи</h3>
      <div className="card" style={{ padding: 12 }}>
        <div className="small muted">Дальше: таблица + смена ролей.</div>
      </div>
    </div>
  );
}
