export function HomePage() {
  return (
    <div className="container" style={{ maxWidth: 1400, paddingTop: 18 }}>
      <h2 className="fw-bold mb-2">Главная</h2>
      <div className="text-muted">
        Главная страница (лендинг) в разработке.
      </div>
    </div>
  );
}
export default HomePage;
