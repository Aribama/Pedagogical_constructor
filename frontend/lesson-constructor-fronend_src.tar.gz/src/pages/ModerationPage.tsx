

export function ModerationPage() {
  return (
    <div className="container">
      <h3>Модерация карточек</h3>
      <div className="card" style={{ padding: 12 }}>
        <div className="small muted">Дальше: список pending + approve/reject.</div>
      </div>
    </div>
  );
}
