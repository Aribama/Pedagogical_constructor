import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
  autosaveScenarioItems,
  createScenario,
  deleteScenario,
  getScenario,
  updateScenario,
} from "../api/scenarios";
import { Scenario, ScenarioItem } from "../types/scenarios";

type ItemUI = ScenarioItem & {
  // UI-only (мягкая поддержка будущих полей)
  title?: string | null;
  description?: string | null;
  card_id?: number | null;
  duration_minutes?: number | null;
  order?: number | null;
  stage?: string | null;
};

const isFiniteNumber = (v: unknown): v is number =>
  typeof v === "number" && Number.isFinite(v);

const toIntOrNull = (v: string): number | null => {
  const n = Number(v);
  if (!Number.isFinite(n)) return null;
  const i = Math.trunc(n);
  if (i < 0) return null;
  return i;
};

const normalizeItems = (items: ScenarioItem[] | null | undefined): ItemUI[] => {
  if (!Array.isArray(items)) return [];
  return items.map((it: any, idx: number) => {
    // поддержим разные возможные поля (на случай изменения схемы)
    const duration =
      isFiniteNumber(it.duration_minutes) ? it.duration_minutes : it.duration;
    const order = isFiniteNumber(it.order) ? it.order : idx + 1;

    return {
      ...it,
      duration_minutes: duration ?? null,
      order: order ?? null,
    } as ItemUI;
  });
};

const itemsToPayload = (items: ItemUI[]) =>
  items.map((it, idx) => ({
    id: it.id ?? null,
    scenario: it.scenario ?? null,
    card: it.card ?? null,
    stage: (it as any).stage ?? null,
    order: (it as any).order ?? idx + 1,
    duration_minutes:
      (it as any).duration_minutes ?? (it as any).duration ?? null,
  }));

export function ScenarioPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const scenarioId = useMemo(() => {
    const n = Number(id);
    return Number.isFinite(n) ? n : null;
  }, [id]);

  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [draftName, setDraftName] = useState<string>("");
  const [draftNote, setDraftNote] = useState<string>("");
  const [draftGrade, setDraftGrade] = useState<number | null>(null);
  const [draftLessonSubject, setDraftLessonSubject] = useState<string>("");
  const [draftGoal, setDraftGoal] = useState<string>("");

  const [draftStartGoals, setDraftStartGoals] = useState<string>("");
  const [draftStartRequirements, setDraftStartRequirements] =
    useState<string>("");
  const [draftStartEnvironment, setDraftStartEnvironment] =
    useState<string>("");

  const [draftItems, setDraftItems] = useState<ItemUI[]>([]);
  const [isDirty, setIsDirty] = useState<boolean>(false);

  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);
  const [showNameRequired, setShowNameRequired] = useState<boolean>(false);

  const loadAbort = useRef<AbortController | null>(null);

  const loadScenario = async () => {
    if (!scenarioId) {
      setError("Некорректный ID сценария.");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    // отменим предыдущий запрос
    if (loadAbort.current) loadAbort.current.abort();
    loadAbort.current = new AbortController();

    try {
      const s = await getScenario(scenarioId);
      setScenario(s);

      setDraftName(s.name ?? "");
      setDraftNote(s.note ?? "");

      setDraftGrade(s.grade ?? null);
      setDraftLessonSubject(s.subject ?? "");
      setDraftGoal(s.goal ?? "");

      setDraftStartGoals(s.start_goals ?? "");
      setDraftStartRequirements(s.start_requirements ?? "");
      setDraftStartEnvironment(s.start_environment ?? "");

      setDraftItems(normalizeItems((s as any).items));
      setIsDirty(false);
    } catch (e: any) {
      setError(e?.message ?? "Не удалось загрузить сценарий.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadScenario();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scenarioId]);

  const canSave = useMemo(() => {
    return (draftName ?? "").trim().length > 0;
  }, [draftName]);

  const buildScenarioPatchPayload = (): Partial<Scenario> => ({
    name: draftName,
    note: draftNote,

    grade: draftGrade,
    subject: draftLessonSubject?.trim() ? draftLessonSubject : null,
    goal: draftGoal?.trim() ? draftGoal : null,

    start_goals: draftStartGoals,
    start_requirements: draftStartRequirements,
    start_environment: draftStartEnvironment,
  });

  const persistDraft = async (opts?: { force?: boolean }) => {
    if (saving) return;
    if (!scenario) return;

    if (!canSave) {
      setShowNameRequired(true);
      return;
    }

    if (!isDirty && !opts?.force) return;

    setSaving(true);
    setError(null);

    try {
      const baseScenario = scenario;

      const scenarioPayload = buildScenarioPatchPayload();
      const itemsPayload = itemsToPayload(draftItems);

      // 1) PATCH сценарий
      await updateScenario(baseScenario.id, scenarioPayload);

      // 2) PUT items (не используем updated.id, чтобы не получить undefined)
      const updatedItems = await autosaveScenarioItems(
        baseScenario.id,
        itemsToPayload(draftItems)
      );

      setScenario(updatedItems);

      // обновим драфты, если бэк что-то нормализовал
      setDraftItems(normalizeItems((updatedItems as any).items));

      setIsDirty(false);
    } catch (e: any) {
      setError(e?.message ?? "Request failed");
    } finally {
      setSaving(false);
    }
  };

  const onSaveClick = async () => {
    await persistDraft({ force: true });
  };

  const onSaveAsClick = async () => {
    if (!scenario) return;

    if (!canSave) {
      setShowNameRequired(true);
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const payload: Partial<Scenario> = {
        ...buildScenarioPatchPayload(),
      };

      // создаём новый сценарий (копию) на бэке
      const created = await createScenario(payload);

      // переносим items
      await autosaveScenarioItems(created.id, itemsToPayload(draftItems));

      // переходим на новый сценарий
      navigate(`/scenario/${created.id}`);
    } catch (e: any) {
      setError(e?.message ?? "Request failed");
    } finally {
      setSaving(false);
    }
  };

  const onDeleteClick = async () => {
    if (!scenario) return;
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!scenario) return;
    setSaving(true);
    setError(null);

    try {
      await deleteScenario(scenario.id);
      navigate("/");
    } catch (e: any) {
      setError(e?.message ?? "Не удалось удалить сценарий.");
    } finally {
      setSaving(false);
      setShowDeleteConfirm(false);
    }
  };

  const cancelDelete = () => setShowDeleteConfirm(false);

  const updateItemDuration = (idx: number, minutes: number | null) => {
    setDraftItems((prev) => {
      const copy = [...prev];
      const it = { ...(copy[idx] as any) };
      it.duration_minutes = minutes;
      copy[idx] = it;
      return copy;
    });
    setIsDirty(true);
  };

  const updateItemStage = (idx: number, stage: string | null) => {
    setDraftItems((prev) => {
      const copy = [...prev];
      const it = { ...(copy[idx] as any) };
      (it as any).stage = stage;
      copy[idx] = it;
      return copy;
    });
    setIsDirty(true);
  };

  const updateItemOrder = (idx: number, order: number | null) => {
    setDraftItems((prev) => {
      const copy = [...prev];
      const it = { ...(copy[idx] as any) };
      (it as any).order = order;
      copy[idx] = it;
      return copy;
    });
    setIsDirty(true);
  };

  if (loading) {
    return (
      <div className="container py-4">
        <div className="alert alert-secondary mb-0">Загрузка...</div>
      </div>
    );
  }

  if (error && !scenario) {
    return (
      <div className="container py-4">
        <div className="alert alert-danger">{error}</div>
        <button className="btn btn-outline-primary" onClick={loadScenario}>
          Повторить
        </button>
      </div>
    );
  }

  if (!scenario) {
    return (
      <div className="container py-4">
        <div className="alert alert-warning">Сценарий не найден.</div>
      </div>
    );
  }

  return (
    <div className="container py-4">
      <div className="d-flex align-items-center justify-content-between gap-2 flex-wrap">
        <div>
          <div className="h4 mb-1">Сценарий занятия</div>
          <div className="text-muted">ID: {scenario.id}</div>
        </div>

        <div className="d-flex gap-2">
          <button
            className="btn btn-outline-secondary"
            onClick={() => persistDraft()}
            disabled={saving || !isDirty}
            title="Автосохранение"
          >
            {saving ? "Сохранение..." : "Сохранить"}
          </button>

          <button
            className="btn btn-primary"
            onClick={onSaveClick}
            disabled={saving}
          >
            Сохранить (принудительно)
          </button>

          <button
            className="btn btn-outline-primary"
            onClick={onSaveAsClick}
            disabled={saving}
          >
            Сохранить как...
          </button>

          <button
            className="btn btn-outline-danger"
            onClick={onDeleteClick}
            disabled={saving}
          >
            Удалить
          </button>
        </div>
      </div>

      {error ? (
        <div className="alert alert-warning mt-3 mb-0">{error}</div>
      ) : null}

      {/* Паспорт занятия */}
      <div className="card mt-3">
        <div className="card-header fw-semibold">Паспорт занятия</div>
        <div className="card-body">
          <div className="row g-3">
            <div className="col-12 col-lg-6">
              <label className="form-label">Название</label>
              <input
                className="form-control"
                value={draftName}
                onChange={(e) => {
                  setDraftName(e.target.value);
                  setIsDirty(true);
                }}
                placeholder="Название сценария"
              />
            </div>

            <div className="col-12 col-lg-6">
              <label className="form-label">Примечание</label>
              <input
                className="form-control"
                value={draftNote}
                onChange={(e) => {
                  setDraftNote(e.target.value);
                  setIsDirty(true);
                }}
                placeholder="Короткая заметка"
              />
            </div>

            <div className="col-12 col-lg-3">
              <label className="form-label">Класс</label>
              <input
                className="form-control"
                inputMode="numeric"
                value={draftGrade ?? ""}
                onChange={(e) => {
                  setDraftGrade(toIntOrNull(e.target.value));
                  setIsDirty(true);
                }}
                placeholder="Например: 5"
              />
            </div>

            <div className="col-12 col-lg-9">
              <label className="form-label">Учебный предмет</label>
              <input
                className="form-control"
                value={draftLessonSubject}
                onChange={(e) => {
                  setDraftLessonSubject(e.target.value);
                  setIsDirty(true);
                }}
                placeholder="Например: Математика"
              />
            </div>

            <div className="col-12">
              <label className="form-label">Цель занятия</label>
              <textarea
                className="form-control"
                value={draftGoal}
                onChange={(e) => {
                  setDraftGoal(e.target.value);
                  setIsDirty(true);
                }}
                placeholder="Кратко: чего хотим достичь на занятии"
                rows={3}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Параметры (стартовые вводные) */}
      <div className="card mt-3">
        <div className="card-header fw-semibold">Параметры</div>
        <div className="card-body">
          <div className="row g-3">
            <div className="col-12">
              <label className="form-label">Стартовые цели</label>
              <textarea
                className="form-control"
                value={draftStartGoals}
                onChange={(e) => {
                  setDraftStartGoals(e.target.value);
                  setIsDirty(true);
                }}
                rows={3}
              />
            </div>

            <div className="col-12">
              <label className="form-label">Требования</label>
              <textarea
                className="form-control"
                value={draftStartRequirements}
                onChange={(e) => {
                  setDraftStartRequirements(e.target.value);
                  setIsDirty(true);
                }}
                rows={3}
              />
            </div>

            <div className="col-12">
              <label className="form-label">Среда</label>
              <textarea
                className="form-control"
                value={draftStartEnvironment}
                onChange={(e) => {
                  setDraftStartEnvironment(e.target.value);
                  setIsDirty(true);
                }}
                rows={3}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Дидактические приемы / Items */}
      <div className="card mt-3">
        <div className="card-header fw-semibold">
          Дидактические приёмы / элементы сценария
        </div>

        <div className="card-body">
          {draftItems.length === 0 ? (
            <div className="text-muted">Элементов пока нет.</div>
          ) : (
            <div className="table-responsive">
              <table className="table table-sm align-middle">
                <thead>
                  <tr>
                    <th style={{ width: 90 }}>Порядок</th>
                    <th>Элемент</th>
                    <th style={{ width: 220 }}>Этап</th>
                    <th style={{ width: 160 }}>Время (мин)</th>
                  </tr>
                </thead>
                <tbody>
                  {draftItems.map((it, idx) => (
                    <tr key={it.id ?? `${(it as any).card_id ?? "x"}-${idx}`}>
                      <td>
                        <input
                          className="form-control form-control-sm"
                          inputMode="numeric"
                          value={(it as any).order ?? idx + 1}
                          onChange={(e) =>
                            updateItemOrder(idx, toIntOrNull(e.target.value))
                          }
                        />
                      </td>
                      <td>
                        <div className="fw-semibold">
                          {(it as any).title ?? "Элемент"}
                        </div>
                        {(it as any).description ? (
                          <div className="text-muted small">
                            {(it as any).description}
                          </div>
                        ) : null}
                      </td>
                      <td>
                        <select
                          className="form-select form-select-sm"
                          value={(it as any).stage ?? ""}
                          onChange={(e) =>
                            updateItemStage(idx, e.target.value || null)
                          }
                        >
                          <option value="">—</option>
                          <option value="beginning">Начало</option>
                          <option value="middle">Основная часть</option>
                          <option value="end">Завершение</option>
                        </select>
                      </td>
                      <td>
                        <input
                          className="form-control form-control-sm"
                          inputMode="numeric"
                          value={(it as any).duration_minutes ?? ""}
                          onChange={(e) =>
                            updateItemDuration(idx, toIntOrNull(e.target.value))
                          }
                          placeholder="мин"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="text-muted small">
                После изменения времени нажмите «Сохранить» или дождитесь
                автосохранения.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal: confirm delete */}
      {showDeleteConfirm ? (
        <>
          <div
            className="modal show"
            style={{ display: "block" }}
            role="dialog"
            aria-modal="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <div className="modal-title fw-semibold">Удалить сценарий?</div>
                  <button
                    type="button"
                    className="btn-close"
                    aria-label="Close"
                    onClick={cancelDelete}
                  />
                </div>
                <div className="modal-body">
                  Сценарий будет удалён без возможности восстановления.
                </div>
                <div className="modal-footer">
                  <button
                    className="btn btn-outline-secondary"
                    onClick={cancelDelete}
                    disabled={saving}
                  >
                    Отмена
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={confirmDelete}
                    disabled={saving}
                  >
                    Удалить
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="modal-backdrop show" />
        </>
      ) : null}

      {/* Modal: попытка сохранить без названия */}
      {showNameRequired ? (
        <>
          <div
            className="modal show"
            style={{ display: "block" }}
            role="dialog"
            aria-modal="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <div className="modal-title fw-semibold">
                    Нельзя сохранить без названия
                  </div>
                  <button
                    type="button"
                    className="btn-close"
                    aria-label="Close"
                    onClick={() => setShowNameRequired(false)}
                  />
                </div>
                <div className="modal-body">
                  Чтобы сохранить сценарий, укажите его название в разделе
                  «Паспорт занятия».
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => setShowNameRequired(false)}
                  >
                    Понял
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="modal-backdrop show" />
        </>
      ) : null}
    </div>
  );
}

export default ScenarioPage;
